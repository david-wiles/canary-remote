#!/bin/bash

sudo mount -o remount,noexec /tmp