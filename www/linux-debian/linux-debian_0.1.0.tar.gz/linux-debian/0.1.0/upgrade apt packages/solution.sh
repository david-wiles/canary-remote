#!/bin/bash

sudo apt upgrade -y