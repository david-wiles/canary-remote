#!/bin/bash

sudo passwd -l nginx