#!/bin/bash

sudo chown -R root:root /etc/nginx